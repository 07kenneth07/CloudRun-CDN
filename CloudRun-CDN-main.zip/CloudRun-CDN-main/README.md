# CloudRun-CDN
1- copiar el repositorio a su cuenta

![Selección_025](https://github.com/user-attachments/assets/7e408d98-3311-4865-b659-9242366d1f2a)

2- conectar su repositorio github

![Selección_016](https://github.com/user-attachments/assets/c72a8290-b842-4e73-a3b9-471a1b504c71)

![Selección_017](https://github.com/user-attachments/assets/b169aa30-0e33-4ed0-9916-5062ae26129f)

![Selección_018](https://github.com/user-attachments/assets/389b04d4-4d22-4dac-a2ec-283ec7637a40)

![Selección_019](https://github.com/user-attachments/assets/b418679b-e2ca-4aec-9145-568f3fed7741)

![Selección_020](https://github.com/user-attachments/assets/a9405049-883f-4a68-a3f9-7abc2fa64aa4)

![Selección_021](https://github.com/user-attachments/assets/e0be5053-ad4e-492b-a19b-ecd6604a28c0)

![Selección_022](https://github.com/user-attachments/assets/b28bf97f-7e03-4bfd-942d-51d4b00248c3)

![Selección_023](https://github.com/user-attachments/assets/b441a657-af40-4cab-b915-c3614427df6f)

3- una vez usada la key, el bot les genera una nueva key de reimplentacion, si requiere reimplenetar el contenedor devera usar esta key

![Selección_024](https://github.com/user-attachments/assets/d745299f-cd7f-4b8d-8e78-5e6e98b7a53c)
